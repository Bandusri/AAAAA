package furShop;
import javax.swing.*;
import java.awt.*;

public class PreviewPanel extends JPanel {
    public PreviewPanel() {
        setPreferredSize(new Dimension(200, 400));
        setBackground(Color.WHITE);


        // Add components to display preview (2D or 3D view) of designed furniture
    }
}
